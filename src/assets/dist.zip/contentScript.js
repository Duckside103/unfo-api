/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/utils/types.ts":
/*!****************************!*\
  !*** ./src/utils/types.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RequestType: () => (/* binding */ RequestType),
/* harmony export */   State: () => (/* binding */ State)
/* harmony export */ });
var RequestType;
(function (RequestType) {
    RequestType[RequestType["SendQuestion"] = 0] = "SendQuestion";
    RequestType[RequestType["GetAnswers"] = 1] = "GetAnswers";
    RequestType[RequestType["RenderState"] = 2] = "RenderState";
})(RequestType || (RequestType = {}));
var State;
(function (State) {
    State["Idle"] = "idle";
    State["Loading"] = "loading";
    State["Error"] = "error";
})(State || (State = {}));


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!********************************************!*\
  !*** ./src/contentScript/contentScript.ts ***!
  \********************************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _utils_types__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/types */ "./src/utils/types.ts");
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

window.onload = () => {
    let appState = _utils_types__WEBPACK_IMPORTED_MODULE_0__.State.Idle;
    let answers = [];
    let answerIndex = 0;
    let answersLength = 0;
    let stateElm = undefined;
    console.log("onload");
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.type === _utils_types__WEBPACK_IMPORTED_MODULE_0__.RequestType.RenderState) {
            stateElm = document.createElement("div");
            stateElm.id = "net-state";
            stateElm.innerHTML = '<div id="net-state-child"></div>';
            document.body.appendChild(stateElm);
        }
    });
    window.addEventListener("click", requestSendQuestion);
    window.addEventListener("keypress", requestGetAnswers);
    function requestSendQuestion(e) {
        return __awaiter(this, void 0, void 0, function* () {
            const isDoubleClick = e.detail === 2;
            const isTripleClick = e.detail === 3;
            if (isDoubleClick && answers.length > 0) {
                /**
                 * Increase answer index
                 */
                if (answerIndex >= answersLength - 1) {
                    answerIndex = 0;
                }
                else {
                    answerIndex++;
                }
                renderAnswer(answers[answerIndex]);
            }
            if (isTripleClick) {
                stateElm.className = "";
                stateElm.classList.add(_utils_types__WEBPACK_IMPORTED_MODULE_0__.State.Loading);
                /**
                 * Send a signal to capture the tab
                 */
                appState = yield chrome.runtime.sendMessage({
                    type: _utils_types__WEBPACK_IMPORTED_MODULE_0__.RequestType.SendQuestion,
                });
                stateElm.className = "";
                stateElm.classList.add(appState);
            }
        });
    }
    function requestGetAnswers(e) {
        return __awaiter(this, void 0, void 0, function* () {
            if (e.key === "Enter") {
                stateElm.className = "";
                stateElm.classList.add(_utils_types__WEBPACK_IMPORTED_MODULE_0__.State.Loading);
                /**
                 * Send a signal to get answers
                 */
                const { result, state } = yield chrome.runtime.sendMessage({
                    type: _utils_types__WEBPACK_IMPORTED_MODULE_0__.RequestType.GetAnswers,
                });
                answers = [...result];
                answersLength = result.length;
                if (answers.length > 0) {
                    answerIndex = 0;
                    renderAnswer(answers[answerIndex]);
                }
                stateElm.className = "";
                stateElm.classList.add(state);
            }
        });
    }
    /**
     * Render the current answer
     */
    function renderAnswer(answer) {
        /**
         * Remove previous div#net
         */
        const prevNetElm = document.querySelector("div#net");
        if (prevNetElm)
            prevNetElm.remove();
        const answers = answer.value;
        if (document.title.startsWith("(")) {
            const [_, ...rawTitle] = document.title.split(/[()]+/).filter(Boolean);
            document.title = `(${answer.no}) ${rawTitle.join("")}`;
        }
        else {
            document.title = `(${answer.no}) ${document.title}`;
        }
        const netElm = document.createElement("div");
        netElm.id = "net";
        netElm.innerHTML = ["a", "b", "c", "d"]
            .map((letter) => {
            const isAnswer = answers.includes(letter);
            return `<div class="net-option ${letter} ${isAnswer ? "isAnswer" : ""}"></div>`;
        })
            .join("");
        document.body.appendChild(netElm);
    }
};

})();

/******/ })()
;
//# sourceMappingURL=contentScript.js.map